# Giải trình: COUNT(o.order_id) thay vì COUNT(*)

Với `LEFT JOIN`, khách hàng chưa mua như Charlie vẫn được giữ lại, nhưng các cột của bảng `Orders` trong dòng đó đều là `NULL`.

- `COUNT(*)` đếm **số dòng** của kết quả. Dòng của Charlie vẫn tồn tại nên bị đếm thành **1**, sai so với thực tế là chưa có đơn nào.
- `COUNT(o.order_id)` chỉ đếm các giá trị **khác NULL**. Charlie có `order_id = NULL` nên kết quả là **0**, đúng nghiệp vụ.

Vì vậy cần đếm trên cột khóa chính của bảng phụ (`Orders`). Nếu dùng `COUNT(*)`, nhóm khách hàng chưa mua sẽ bị gán nhầm 1 đơn hàng, và Marketing không lọc đúng danh sách để tặng Voucher 50%.
