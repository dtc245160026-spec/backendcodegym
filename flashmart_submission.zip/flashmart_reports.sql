-- =====================================================
-- FLASHMART - BÁO CÁO ĐÃ SỬA (MySQL)
-- =====================================================
CREATE DATABASE IF NOT EXISTS flashmart_db;
USE flashmart_db;

-- 1. Tạo bảng và chèn dữ liệu mẫu (chạy lại nhiều lần không bị lỗi trùng khóa)
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Customers;

CREATE TABLE Customers (customer_id INT PRIMARY KEY, name VARCHAR(50));
CREATE TABLE Products  (product_id INT PRIMARY KEY, product_name VARCHAR(50));
CREATE TABLE Orders    (order_id INT PRIMARY KEY, customer_id INT, product_id INT);

INSERT INTO Customers VALUES (1, 'Alice'), (2, 'Bob'), (3, 'Charlie');   -- Charlie chưa từng mua hàng
INSERT INTO Products  VALUES (101, 'Laptop'), (102, 'Mouse'), (103, 'Keyboard'); -- Keyboard chưa từng được bán
INSERT INTO Orders    VALUES (1001, 1, 101), (1002, 1, 102), (1003, 2, 101);

-- ========================================================
-- BÁO CÁO 1: Marketing - tất cả khách hàng kèm số đơn hàng
-- Bảng gốc (Left): Customers | Bảng tham chiếu (Right): Orders
-- COUNT(o.order_id) bỏ qua NULL => Charlie ra 0 (COUNT(*) sẽ ra 1, sai)
-- ========================================================
SELECT c.customer_id, c.name, COUNT(o.order_id) AS total_orders
FROM Customers c
LEFT JOIN Orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name;
-- Kết quả mong đợi: Alice 2 | Bob 1 | Charlie 0

-- ========================================================
-- BÁO CÁO 2: Kho vận - sản phẩm chưa từng được bán (Anti-Join)
-- Bảng gốc (Left): Products | Bảng tham chiếu (Right): Orders
-- ========================================================
SELECT p.product_id, p.product_name
FROM Products p
LEFT JOIN Orders o ON p.product_id = o.product_id
WHERE o.order_id IS NULL;
-- Kết quả mong đợi: (103, 'Keyboard')

-- ========================================================
-- THAM KHẢO: cách viết tương đương cho Báo cáo 2
-- ========================================================
-- NOT EXISTS (nên dùng thay NOT IN, vì NOT IN trả về rỗng nếu subquery có NULL)
SELECT p.product_id, p.product_name
FROM Products p
WHERE NOT EXISTS (SELECT 1 FROM Orders o WHERE o.product_id = p.product_id);

-- ========================================================
-- THAM KHẢO: giả lập FULL OUTER JOIN trong MySQL
-- ========================================================
SELECT c.customer_id, c.name, o.order_id
FROM Customers c LEFT JOIN Orders o ON c.customer_id = o.customer_id
UNION
SELECT c.customer_id, c.name, o.order_id
FROM Customers c RIGHT JOIN Orders o ON c.customer_id = o.customer_id;
